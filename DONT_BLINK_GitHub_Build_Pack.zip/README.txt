DON'T BLINK — PC'siz GitHub Actions derleme paketi

1. GitHub'da boş bir repository oluştur.
2. Bu paketteki dont-blink-project.zip dosyasını repo köküne yükle.
3. .github/workflows/build-apk.yml dosyasını aynı yolu koruyarak yükle.
4. GitHub > Actions > Build DON'T BLINK APK > Run workflow.
5. İşlem bitince workflow sayfasındaki Artifacts bölümünden DONT-BLINK-debug-apk.zip'i indir.
6. ZIP'i telefonda aç; içindeki app-debug.apk dosyasını kur.

GitHub Actions, sanal bir Linux makinesinde Gradle build çalıştırır ve APK'yı artifact olarak saklar.
