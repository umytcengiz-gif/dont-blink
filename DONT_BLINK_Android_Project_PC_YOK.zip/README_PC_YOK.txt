DON'T BLINK — Android APK projesi

PC GEREKMEZ.
Bu proje AndroidIDE/AIDE gibi Android üzerinde çalışan bir IDE ile açılıp derlenebilir.

Özellikler:
- Android kamera izni: Manifest + runtime permission
- WebView tabanlı oyun
- MediaPipe göz/iris takibi için mevcut v2 HTML kullanılabilir
- Göz kırpınca anında ateş
- Dokunmatik yedek kontrol

Not: İlk derlemede internet bağlantısı gerekir; Gradle ve MediaPipe dosyaları indirilebilir.
